I have provided a maze file in the zip. If you want to change the maze, simply edit that file. 

The test.py is where you will test the problem.

I have it set up to print the path of the robot with the maze printed at each step (if  you don't want to print the maze, change print_maze=False). A list of probabilities is printed and then the maze is printed but instead of the colors covering the floors, the probability of the robot being at that position is printed.