import random
import numpy as np
class RobotLocalization:
    def __init__(self, maze):
        # initialize RobotLocalization problem with maze, num states, etc.
        self.maze = maze
        self.num_states = maze.width * maze.height
        # initialize prior distribution
        self.belief = [0] * self.num_states
        # sense the first color and add it to sensed colors
        self.sensed_colors = [self.sense(self.maze.robotloc[0],self.maze.robotloc[1])]
        start_position = maze.robotloc
        # initialize path with start position
        self.path = [start_position]
        # get number of valid states
        total_valid_states = sum(
            1 for i in range(self.num_states) if self.maze.is_floor(i % self.maze.width, i // self.maze.width))
        # adjust prior probabilities such that floors are uniformly distributed and add to 1
        for i in range(self.num_states):
            if self.maze.is_floor(i % self.maze.width, i // self.maze.width):
                self.belief[i] = 1 / total_valid_states

    def move(self, direction):
        # move function takes in a direction and moves the robot in that direction
        x, y = self.maze.robotloc[0], self.maze.robotloc[1]
        if direction == "N":
            new_y = y + 1
            new_x = x
        elif direction == "S":
            new_y = y - 1
            new_x = x
        elif direction == "E":
            new_x = x + 1
            new_y = y
        elif direction == "W":
            new_x = x - 1
            new_y = y
        # if new place is floor, new robot location is new x and new y
        if self.maze.is_floor(new_x, new_y):
            self.maze.robotloc = [new_x, new_y]
            self.path.append([new_x, new_y])
        # if its not a floor, new robot location is old x and y
        else:
            self.path.append([x, y])


    def sense(self, x, y):
        # sense function senses the color at a given location with the given probabilities
        actual_color = self.maze.get_character(x, y)
        # initialize list of colors
        colors = ["r", "g", "y", "b"]
        # initialize all probabilities to 0.04
        probabilities = [0.04] * 4
        # change the probability of the colo the robot is on to 0.88
        actual_color_index = colors.index(actual_color)
        probabilities[actual_color_index] = 0.88
        return random.choices(colors, probabilities)[0]

    def move_and_sense(self, num_movements, print_maze = False):
        # move and sense takes in a random direction and moves the robot in that direction and senses
        directions = ["N", "S", "E", "W"]
        for _ in range(num_movements):
            # choose random direction
            random_direction = random.choice(directions)
            # move the robot in that direction
            self.move(random_direction)
            #add the sensed  color to the sensed color list
            self.sensed_colors.append(self.sense(self.maze.robotloc[0],self.maze.robotloc[1]))
            #print maze at each step if you want (robot doesn't know where it is but
            # can be helpful to see its actual path
            if print_maze:
                print(self.maze)

    def calculate_transition_matrix(self):
        # function that calculates the transition matrix of a maze
        num_states = self.num_states
        transition_matrix = []
        # iterate through each state
        for i in range(num_states):
            if not self.maze.is_floor(i % self.maze.width, i // self.maze.width):
                # If it's a wall, stay in the same spot, probabilities are all 0
                probabilities = [0] * num_states
                transition_matrix.append(probabilities)
            else:
                # Calculate probabilities for each direction
                x, y = i % self.maze.width, i // self.maze.width
                # initialize probabilities to 0
                probabilities = [0] * num_states
                # possible directions
                directions = [(0, 1), (0, -1), (1, 0), (-1, 0)]

                for dx, dy in directions:
                    new_x, new_y = x + dx, y + dy
                    # if new state is floor, add 0.25 to the new_state (0.25 bc four directions)
                    if self.maze.is_floor(new_x, new_y):
                        new_state = new_y * self.maze.width + new_x
                        probabilities[new_state] += 0.25
                    # if new state is a floor, old states probability goes up by 0.25
                    else:
                        probabilities[i] += 0.25
                transition_matrix.append(probabilities)
        return transition_matrix

    def color_probability_matrices_rgyb(self):
        # for each color, we want a probability of that color being sensed at a given spot
        sensor_prob_matrices = {}
        colors = ['r', 'g', 'y', 'b']
        # go through each color and make matrix
        for color in colors:
            color_matrix = []
            # go through each location
            for i in range(self.num_states):
                x = i % self.maze.width
                y = i // self.maze.width
                current_color = self.maze.get_character(x, y)
                # if it is not a wall
                if current_color != "#":  # Exclude walls
                    # and the current color matches that of the maze at that spot, prob is 0.88
                    if current_color == color:
                        color_matrix.append(0.88)
                    # if current color doesnt match color of the spot, prob is 0.04
                    else:
                        color_matrix.append(0.04)
                # if wall, prob is 0
                else:
                    color_matrix.append(0)
            sensor_prob_matrices[color] = color_matrix
        return sensor_prob_matrices



    def calculate_final_probabilities(self,sensed_colors):
        # get prior, transition matrix, and color matrix from self
        current_distribution = self.belief.copy()
        transition_matrix = self.calculate_transition_matrix()
        color_matrices = self.color_probability_matrices_rgyb()
        # iterate through the colors
        for sensed_color in sensed_colors:
            # transition probabilities by dotting transition matrix with current distribution
            transition_probabilities = np.dot(transition_matrix, current_distribution)
            # extract color matrix we want based on sensed color
            color_matrix = color_matrices[sensed_color]
            # multiply this transition matrix with the color matrix
            final_distribution = np.multiply(transition_probabilities, color_matrix)
            # normalize so probs add up to 1
            total_prob = sum(final_distribution)
            final_distribution = [prob / total_prob for prob in final_distribution]
            current_distribution = final_distribution
        return current_distribution

    def print_probabilities_on_maze(self,probabilities):
        # takes probabilities,projects them onto the maze and prints
        for y in range(self.maze.height -1, -1, -1):
            for x in range(self.maze.width):
                idx = y * self.maze.width + x
                if self.maze.is_floor(x, y):
                    print(f'{probabilities[idx]:.2f}', end='\t')
                else:
                    print('#', end='\t')
            print()





