class Maze:
    # used similar Maze code from last time but added a few methods
    def __init__(self, mazefilename):
        # initialize locations and colors list
        self.robotloc = []
        self.colors = []

        f = open(mazefilename)
        lines = []
        for line in f:
            line = line.strip()
            if len(line) == 0:
                pass
            elif line[0] == "\\":
                parms = line.split()
                x = int(parms[1])
                y = int(parms[2])
                self.robotloc.append(x)
                self.robotloc.append(y)
            else:
                lines.append(line)
                # Add color information to the colors list
                self.colors.extend(list(line))
        f.close()

        self.width = len(lines[0])
        self.height = len(lines)
        self.map = list("".join(lines))

    def index(self, x, y):
        # gets index of position assuming you start at bottom left
        return (self.height - y - 1) * self.width + x

    def is_floor(self, x, y):
        # determine if a spot is a floor
        if x < 0 or x >= self.width:
            return False
        if y < 0 or y >= self.height:
            return False
        return self.map[self.index(x, y)] != "#"


    def has_robot(self, x, y):
        # determine if a robot is at a given location
        if x < 0 or x >= self.width:
            return False
        if y < 0 or y >= self.height:
            return False
        for i in range(0, len(self.robotloc), 2):
            rx = self.robotloc[i]
            ry = self.robotloc[i + 1]
            if rx == x and ry == y:
                return True
        return False

    def create_render_list(self):
        renderlist = list(self.map)
        robot_number = 0
        for index in range(0, len(self.robotloc), 2):
            x = self.robotloc[index]
            y = self.robotloc[index + 1]
            renderlist[self.index(x, y)] = robotchar(robot_number)
            robot_number += 1
        return renderlist

    def __str__(self):
        renderlist = self.create_render_list()
        s = ""
        for y in range(self.height - 1, -1, -1):
            for x in range(self.width):
                s += renderlist[self.index(x, y)]
            s += "\n"
        return s

    def get_character(self, x, y):
        # gets value of character at a certain spot
        return self.map[self.index(x, y)]

    def get_valid_moves(self, x, y):
        # gets valid moves for a robot
        moves = [(0, 1), (0, -1), (1, 0), (-1, 0)]
        valid_moves = []

        for move in moves:
            new_x = x + move[0]
            new_y = y + move[1]

            if self.is_floor(new_x, new_y):
                valid_moves.append(move)

        return valid_moves
def robotchar(robot_number):
    return chr(ord("A") + robot_number)