from Robot_Localization import *
from Maze import *
maze = Maze("HMM.maz")
# initialize problem
robot_localization = RobotLocalization(maze)
# Used 4 movements but feel free to change and if the maze is printed
robot_localization.move_and_sense(4,print_maze=True)
# Also printed the robots actual path (The robot doesn't know this)
print(f"Robot path:{robot_localization.path}\n")

# get list of colors
colors = robot_localization.sensed_colors
# given these colors, calculate final probabilities and print
probs = robot_localization.calculate_final_probabilities(colors)
print(f"Probabilities at each index:{probs}\n")
# print probabilities on maze rounded to two decimal points
robot_localization.print_probabilities_on_maze(probs)