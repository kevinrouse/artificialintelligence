from SAT import *
from display import display_sudoku_solution

# testing one_cell with gsat
random.seed(1)
puzzle_name = "one_cell.cnf"
sol_filename = puzzle_name[:-4] + ".sol"

sat = SAT(puzzle_name)

result = sat.gsat(max_steps=3500, h=0.3)
print('testing one_cell with gsat')
if result:
    sat.write_solution(sol_filename)
    print(f"Result:{result}")
    print(f"Number of gsat iterations:{sat.gsat_iterations}")
    print(f"Solution saved to {sol_filename}")
    print('\n')
else:
    print("No satisfying assignment found within max steps.")
    print('\n')
display_sudoku_solution(sol_filename)
##########################
# Testing one_cell with walkSAT
print('testing one_cell with walksat')
puzzle_name = "one_cell.cnf"
sol_filename = puzzle_name[:-4] + ".sol"

sat = SAT(puzzle_name)

result = sat.walksat(max_steps=3500, h=0.3)
if result:
    sat.write_solution(sol_filename)
    print(f"Result:{result}")
    print(f"Number of gsat iterations:{sat.walksat_iterations}")
    print(f"Solution saved to {sol_filename}")
    print('\n')
else:
    print("No satisfying assignment found within max steps.")
display_sudoku_solution(sol_filename)
#######
# testing all cells with gsat
puzzle_name = "all_cells.cnf"
sol_filename = puzzle_name[:-4] + ".sol"

sat = SAT(puzzle_name)

result = sat.walksat(max_steps=3500, h=0.3)
print('testing all_cells with walksat')
if result:
    sat.write_solution(sol_filename)
    print(f"Result:{result}")
    print(f"Number of walksat iterations:{sat.walksat_iterations}")
    print(f"Solution saved to {sol_filename}")
    print('\n')
else:
    print("No satisfying assignment found within max steps.")
    print('\n')
display_sudoku_solution(sol_filename)
####################
puzzle_name = "rows.cnf"
sol_filename = puzzle_name[:-4] + ".sol"

sat = SAT(puzzle_name)
result = sat.walksat(max_steps=3500, h=0.3)
print('testing rows.cnf with walksat')
if result:
    sat.write_solution(sol_filename)
    print(f"Result:{result}")
    print(f"Number of walksat iterations:{sat.walksat_iterations}")
    print(f"Solution saved to {sol_filename}")
    print('\n')
else:
    print("No satisfying assignment found within max steps.")
    print('\n')
display_sudoku_solution(sol_filename)
####################
puzzle_name = "rows_and_cols.cnf"
sol_filename = puzzle_name[:-4] + ".sol"

sat = SAT(puzzle_name)
result = sat.walksat(max_steps=3500, h=0.3)
print('testing rows_and_cols.cnf with walksat')
if result:
    sat.write_solution(sol_filename)
    print(f"Result:{result}")
    print(f"Number of walksat iterations:{sat.walksat_iterations}")
    print(f"Solution saved to {sol_filename}")
    print('\n')
else:
    print("No satisfying assignment found within max steps.")
    print('\n')
display_sudoku_solution(sol_filename)
##################
puzzle_name = "rules.cnf"
sol_filename = puzzle_name[:-4] + ".sol"

sat = SAT(puzzle_name)
result = sat.walksat(max_steps=3500, h=0.3)
print('testing rules.cnf with walksat')
if result:
    sat.write_solution(sol_filename)
    print(f"Result:{result}")
    print(f"Number of walksat iterations:{sat.walksat_iterations}")
    print(f"Solution saved to {sol_filename}")
    print('\n')
else:
    print("No satisfying assignment found within max steps.")
    print('\n')
display_sudoku_solution(sol_filename)