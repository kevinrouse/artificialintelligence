import random

import random

class SAT:
    # initialize clauses, get a list of variables, and make a model
    def __init__(self, cnf_file):
        self.clauses = self.load_cnf(cnf_file)
        self.variables = list(set(abs(literal) for clause in self.clauses for literal in clause))
        # each variable can either be true or false
        self.model = [random.choice([var, -var]) for var in self.variables]
        # keep track of number of iterations
        self.gsat_iterations = 0
        self.walksat_iterations = 0
    def load_cnf(self, cnf_file):
        # loads the cnf file into a list of lists of clauses
        with open(cnf_file, 'r') as file:
            return [[int(literal) for literal in line.split()] for line in file]

    def is_satisfied(self):
        # a model is satisfied if for every clause, there is a literal in the model that matches with the clause
        return all(any(literal in self.model for literal in clause) for clause in self.clauses)

    def count_satisfied_clauses(self):
        # counts how many clauses are satisfied
        counter = 0
        for clause in self.clauses:
            if any(literal in self.model for literal in clause):
                counter +=1
        return counter

    def gsat(self, max_steps, h):
        # implement a max steps parameter since gsat can take a long time
        for _ in range(max_steps):
            self.gsat_iterations += 1
            # if all clauses are satisfied, return the model
            if self.is_satisfied():
                return self.model
            # select a random number between 0 and 1
            # if it is greater than h pick a random variable and flip it
            if random.random() > h:
                var_to_flip = random.choice(self.model)
                idx = self.model.index(var_to_flip)
                self.model[idx] = -var_to_flip
            # if the number is less than h, find the highest scoring variable (how many clauses
            # would be satisfied if the variable were flipped and flip it)
            else:
                # initialize empty best vars list and low max satisfaction number
                best_vars = []
                max_satisfaction = -1

                for var in self.model:
                    # get index of each variable
                    idx = self.model.index(var)
                    # flip that variable in the model
                    self.model[idx] = -var
                    # count how many clauses are satisfied
                    satisfaction = self.count_satisfied_clauses()
                    # if new best variable, make it best_var
                    if satisfaction > max_satisfaction:
                        best_vars = [var]
                        max_satisfaction = satisfaction
                    # if same score, keep both
                    elif satisfaction == max_satisfaction:
                        best_vars.append(var)
                    # change model back to what it was
                    self.model[idx] = var
                # take a random choice from the best vars if more than 1
                var_to_flip = random.choice(best_vars)
                # negate the best variable
                idx = self.model.index(var_to_flip)
                self.model[idx] = -var_to_flip

        return self.model

    def walksat(self, max_steps, h):
        for _ in range(max_steps):
            self.walksat_iterations += 1
            if self.is_satisfied():
                return self.model

            unsatisfied_clauses = [clause for clause in self.clauses if
                                   not any(literal in self.model for literal in clause)]

            random_clause = random.choice(unsatisfied_clauses)
            candidate_variables = [abs(literal) for literal in random_clause]

            if random.random() > h:
                var_to_flip = random.choice(candidate_variables)
                idx = self.model.index(var_to_flip) if var_to_flip in self.model else self.model.index(-var_to_flip)
                self.model[idx] = -var_to_flip
            else:
                best_vars = []
                max_satisfaction = -1
                for var in candidate_variables:
                    idx = self.model.index(var) if var in self.model else self.model.index(-var)
                    self.model[idx] = -self.model[idx]  # Change this line
                    satisfaction = self.count_satisfied_clauses()
                    if satisfaction > max_satisfaction:
                        best_vars = [var]
                        max_satisfaction = satisfaction
                    elif satisfaction == max_satisfaction:
                        best_vars.append(var)

                    self.model[idx] = -self.model[idx]

                var_to_flip = random.choice(best_vars)
                idx = self.model.index(var_to_flip)if var_to_flip in self.model else self.model.index(-var_to_flip)
                self.model[idx] = -var_to_flip

        return self.model

    def write_solution(self, sol_filename):
        with open(sol_filename, 'w') as file:
            for var in self.model:
                file.write(f"{var}\n")


