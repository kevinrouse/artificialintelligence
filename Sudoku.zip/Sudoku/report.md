# Sudoku and propositional logic

## Introduction
The goal of this project is to solve a sudoku puzzle using propositional logic. The rules of sudoku were given in the form of cnf (conjunctive normal form files). The goal is to create a solver such that a state is created that follows all of the rules of a given cnf. The two algorithms that will be used are GSAT and WalkSAT which will be discussed in detail in this report.

## GSAT
Both the GSAT and WalkSAT algorithms are located in SAT.py. A load_cnf function was created which converted each line in the cnf into a clause. A list of variables was created which consisted of each unique variable in the cnf. A random model was initiated where each variable was assigned true or false. I decided to make the representation of true and false the positive variable for true (ex. 119) and the negative variable for false (ex. -119). This matches up with how the cnf files are written making comparisons easier.

This random model is then used in the gsat method. The first step of the GSAT algorithm is to check if the model satisfies all of the rules. The next step is to pick a random number between 0 and 1. If the number is greater than a threshold, h, a random variable's assignment is changed. If the number is less than h, we find the variable that would satisfy the most clauses if flipped and flip that variable. 

However, this algorithm is very slow and only gives a quick solution for one_cell. 

## WalkSAT
WalkSAT is similar to GSAT but instead of figuring out which variable would satisfy the most clauses if flipped, WalkSAT first picks a random clause. The variables in this clause are then scored in the same was as GSAT. Since WalkSAT has a smaller number of candidate variables, it is faster than GSAT.

## Results
The program was able to solve the one_cell.cnf and all_cells.cnf relatively quickly. WalkSAT was faster than GSAT for these two problems. However, for the remainder of the problems, both algorithms are too slow to solve the problems in a reasonable time. With the maximum number of iterations set to 3500, the results seem to be on the right track but are not quite right. Given enough time, this algorithm will find the result but can definitely use some optimization to speed up the result. 

