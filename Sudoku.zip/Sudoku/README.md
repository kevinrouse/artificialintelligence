In order to run the cnf files that represent the rules of sudoku, go to test.py. In that file, I have labeled which problem is which. In order to run a problem, run that specific chunk and change the max_iterations and h as you would like. I have max iterations set to 3500 as this takes about 5 minutes to run a problem but feel free to change this.

In order to solve the sudoku problems, go to solve_sudoku.py, run the problem you would like, and feel free to change the number of iterations and h.
