from display import display_sudoku_solution
import random, sys
from SAT import SAT

if __name__ == "__main__":
    # for testing, always initialize the pseudorandom number generator to output the same sequence
    #  of values:
    random.seed(1)

    puzzle_name = str('puzzle1.cnf')
    sol_filename = puzzle_name + ".sol"

    sat = SAT(puzzle_name)
    print('solving puzzle 1 with walksat')
    result = sat.walksat(max_steps=3500, h=0.3)


    sat.write_solution(sol_filename)
    display_sudoku_solution(sol_filename)
    ##############
    puzzle_name = str('puzzle2.cnf')
    sol_filename = puzzle_name + ".sol"

    sat = SAT(puzzle_name)
    print('solving puzzle 2 with walksat')
    result = sat.walksat(max_steps=3500, h=0.3)

    sat.write_solution(sol_filename)
    display_sudoku_solution(sol_filename)