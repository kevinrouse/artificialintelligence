# Kevin Rouse September 26, 2023
from Maze import Maze
from time import sleep

class SensorlessProblem:

    # initialize class with the start state being any possible starting position in the maze:
    def __init__(self, maze):
        string =  "Blind robot problem: "
        self.maze = maze
        self.states = {(x,y) for x in range(maze.width) for y in range(maze.height) if self.maze.is_floor(x, y)}
        self.start_state = self.states.copy()

    def __str__(self):
        return "Blind robot problem"

    def animate_path(self, path):
        # go through all states
        for state in path:
            print(str(self))
            print('Current State:' + f'{state}')

            # Clear all existing robots
            self.maze.clear_robots()

            # Add robots to the maze based on the tuples in the state
            for x, y in state:
                self.maze.add_robot(x, y)

            sleep(1)
            print(str(self.maze))

    def get_successors(self, states):
        # initialize empty successors list
        successors = []
        movements = [(0, 1), (0, -1), (-1, 0), (1, 0)]

        # iterate through possible movements, each movement is a possible successor
        for dx, dy in movements:
            current_successor = set()
            # get new x and y coordinates
            for x, y in states:
                new_x, new_y = x + dx, y + dy
                # if new spot is a floor, move to new spot
                if self.maze.is_floor(new_x, new_y):
                    new_state = (new_x, new_y)
                    current_successor.add(new_state)
                # if new spot is not a floor, keep old state
                else:
                    old_state = (x, y)
                    current_successor.add(old_state)
            successors.append(current_successor)
        return successors

    def is_goal_state(self, states):
        # goal state is simply if the length of the state is 1
        return len(states) == 1

    def number_of_states_heuristic(self, states):
        # heuristic is how many states there are. the less states, the closer you are to the goal
        return len(states)
    def movement_cost(self, state, new_state):
        # movement cost for this problem is 1
        return 1

## A bit of test code

if __name__ == "__main__":
    test_maze3 = Maze("maze3.maz")
    test_problem = SensorlessProblem(test_maze3)
