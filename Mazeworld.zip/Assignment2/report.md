# Mazeworld Problem and A* Search
# Kevin Rouse September 26, 2023
## Introduction
In this report, we will be solving the mazeworld and sensorless robot problem using A* serach. In mazeworld, there are  certain amount or robots that can move up, down, left, or right. 
There are floors and walls where the floors are safe to cross and the walls are not. The goal of the problem is to have the robots go in order and reach their specified goal locations.

In the sensorless robot problem, the robot does not know where it is but knows the map as well as the direction it is looking. The goal is then to devise a path where the robot can take to know where it  is.
Both of these problems will be solved with A* search with different heuristics.
## Mazes
The mazes were created as series of . and # and saved as .maz files. The Maze.py files contains various information about mazes as well as certain functions that can change the maze such as clear_robots and add_robots
## A* Search Algorithm
The first step to solving the problem was to develop an A* search algorithm that could be used for both problems.
The first step was to initialize an AstarNode class which contained the current state, the heuristic being used, the parent, and the transition cost. This class also has a priority method which is the sum of the transition cost and the heuristic. It also has a method that compares the priority of one Astar node to another.

A backchain function was then implemented which returns the path from the goal state. The main implementation of the astar search was the astar_search problem. This function took in information about the search_problem as well as the heuristic function. The start node was set as an AstarNode and the start state and heuristic function that will be used are passed in. A priority queue was used and with the priority comparison, heappush and heappop allow us to easily keep track of the priorities. A visited dictionary kept track of sites as well as their costs. The Astar node was tested against the goal and returned if it was the goal. If not, the successors are added if they have not been visited or have a lower cost than the cost in the current dictionary. They are then pushed onto the pqueue and the next node is popped off depending on the priority.

## Mazeworld Problem and Mulit-robot coordination
The robots in the mazeworld problem will be represented as a tuple. The first element of the tuple will represent which robots turn it is. Robot A = 0, robot B = 1..... The next element is the x coordinate for robot A, followed by the y coordinate for robot A. The next element is the x coordinate for robot B, and the next is the y coordinate for robot B. 

The upper bound on number of states is (k * (n * n)^k). This is because for however one robot there are n * n possibilities, so for k robots there are n*n^k. Since the robot to move is also considered, there are k * (n * n)^k possibilities.

If there are w walls and we assume n is larger than k, the proportion of walls to available spaces is (w/(n * n)). Therefore, the ampunt of states that represent collisions is (k * (n * n)^k) * (w/(n*n)) or (k * w * (n * n)^k-1).

If there are not many walls in a big maze, BFS is likely not computationally feasible. If there are not many walls, the manhattan distance is a good heuristic and would likely be more computationally efficient.

For this problem, the heuristic used was the manhattan distance, which is the sum of the difference of the absolute value x coordinates and y coordinates. This was picked because it is a good estimate of how far the goal is without considering walls. This is a monotonic function because the cost of the action costs are always positive (manhattan distance cant be negative). 

The A* algorithm was implemented on this problem and the results of 4 different mazes will be discussed. In order to run the mazes, go to test_mazeworld.py, and feel free to animate the path as well. The first maze is the given 5 x 5 test maze. The cost using both the null_heuristic(h = 0) was the same as using the manhattan distance (cost for both was 10). However, A* visited significantly less nodes (214 compared to 3191).

The second example was a 10 x 10 maze with two robots. This maze is interesting because most of the maze is a long corridor with B ahead of A, but in the goal state, A has to be ahead of be. The only way to do this is for them to both travel down the corridor and switch places in a place where the maze opens up more. 

The third example was a 40x40 maze that was pretty open with two robots. I wanted to see if a big maze could visit relatively few nodes if it were open and it only visited 104 nodes with the manhattan heuristic even though it was a large maze.

The fourth example was a maze 5x5 maze with the only path being a line with three robots. I wanted the first and third robot to switch positions, which is impossible but wanted to see how many nodes were visited. 444595 nodes were visited before determining there was no solution, which is more than I was expecting.

The last example was an 8x8 maze which was simply a loop with three robots. However, there was one "hiding spot" that was not part of the loop. The robots then had to switch positions by one of them staying in the hiding spot while another moved ahead.

If this were to be implemented to solve the 8-puzzle problem, the manhattan distance heuristic could be a good choice. However, the positioning of the tiles may matter more important than the distance to the goal, so I would proppose that the heuristic function be the number of misplaced tiles.

The state space of the maze would be two disjoint set, one which represents the empty tile and the other which represents the positions of the other tiles. This would be implemented in my code by saying one of the tiles that neighbors the empty space (vertically or horizontally) must be the one to move in the empty tile. 

## Blind robot with Pacman physics

In order to solve the problem where the robot can know where it is, we will produce a path where no matter where it is, it will be in the same spot. To do this, we initialize the start states as all of the floors in the maze. To get the successors, we move up, down, left, and right. A new set is returned which contains all the new positions of the robot. It is important to noe that if the robot hits a wall, it stays in the same spot. 

The cost of each of getting from one successor to another is 1 and the heuristic is the number of states. This is a good heuristic because the less states there are, the closer we are to the goal. The goal is hit when there is only one state left.

The test_sensorless.py file contains some interesting examples. In the 10x10.maz, most of the maze is a straight vertical line. In order to get to the solution, the path is mostly straight up as this is shrinks the number of states the fastest.

## Previous Work
The paper being reviewed here is "Standley, T., and Korf, R. 2011. Complete algorithms for cooperative pathfinding problems. In Proceedings of the Twenty-Second international joint conference on Artificial Intelligence - Volume Volume One, IJCAI’11, 668–673. AAAI Press." The problem the paper aims to solve is to limit conflict between two agents when trying to reach certain locations. They were very focused on obtaining quick results as they want to use their methods for real time problems. They use A* search with a state space representation called OD and are now trying to couple it with ID or independence detection, ID partitions these agents into different groups and uses OD to find optimal paths. The results showed that these algorithms performed better than previous benchmarks.


