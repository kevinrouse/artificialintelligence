# Kevin Rouse September 26, 2023
from Maze import Maze
from time import sleep

class MazeworldProblem:

    # initialize maze, goal, and start
    def __init__(self, maze, goal_locations):
        self.maze = maze
        self.goal_locations = goal_locations
        # assume we start with robot 0
        self.start_state = (0,) + tuple(maze.robotloc)
    # make string for the mazeworld problem
    def __str__(self):
        string = "Mazeworld problem:\n"
        string += f"Goal Locations: {self.goal_locations}\n"
        string += f"Start State: {self.start_state}\n"
        return string

    def animate_path(self, path):
        # reset the robot locations in the maze
        self.maze.robotloc = tuple(self.start_state[1:])

        for state in path:
            print(str(self))
            print('Current State:' + f'{state}')
            # put robots at whatever locations they are currently at
            self.maze.robotloc = tuple(state[1:])
            sleep(1)

            print(str(self.maze))
    # animates the path the robots take along the path

    # gets LEGAl successors from each state
    def get_successors(self, state):
        # possible moves of robot
        movements = [(0, 1), (0, -1), (-1, 0), (1, 0), (0,0)]
        # initialize successors list
        successors = []
        # robot to move is indicated by first position of state
        robot_to_move = state[0]
        num_robots = (len(state) - 1)//2
        # extract x and y based on robot to move
        x, y = state[2 * robot_to_move + 1], state[2 * robot_to_move + 2]
        # loop through movements and make new states
        for dx, dy in movements:
            new_x, new_y = x + dx, y + dy
            new_state = list(state)
            new_state[2 * robot_to_move + 1] = new_x
            new_state[2 * robot_to_move + 2] = new_y
            # if state is legal, move to next robot and append the state to successors
            if self.is_safe(new_state):
                # use modulus to get next robot
                next_robot = (robot_to_move + 1) % num_robots
                new_state[0] = next_robot
                successors.append(tuple(new_state))
        return successors
    # function used to determine if a state is safe
    def is_safe(self, positions):
        # initialize visited set for robots
        visited_positions = set()
        # robot is safe if it is on a floor and if there is not another robot on it
        for i in range(1, len(positions)-1, 2):
            x, y = positions[i], positions[i + 1]
            if not self.maze.is_floor(x, y) or (x, y) in visited_positions:
                return False
            visited_positions.add((x, y))
        return True
    # determine if the state matches the goal state
    def is_goal_state(self, state):
        return state[1:] == self.goal_locations
    # heuristic used is manhattan distance
    def manhattan_heuristic(self,state):
        total_distance = 0
        # go through each robot and find manhattan distance from the goal location
        for i in range(1, len(state), 2):
            robot_x, robot_y = state[i], state[i + 1]
            goal_x, goal_y = self.goal_locations[i - 1], self.goal_locations[i]
            total_distance += abs(robot_x - goal_x) + abs(robot_y - goal_y)
        return total_distance

    def null_heuristic(self,state):
        # null heuristic is simply 0
        return 0
    def movement_cost(self, state, new_state):
        # movement cost is 0 if robot doesn't move or 1 if it does
        if state[1:] == new_state[1:]:
            return 0
        return 1

## A bit of test code. You might want to add to it to verify that things
#  work as expected.
if __name__ == "__main__":
    test_maze3 = Maze("maze3.maz")
    test_mp = MazeworldProblem(test_maze3, (1, 4, 1, 3, 1, 2))
    print(test_maze3)
    print(test_mp.get_successors((0, 1, 0, 1, 2, 2, 1)))
