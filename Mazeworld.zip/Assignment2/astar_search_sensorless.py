from SearchSolution import SearchSolution
from heapq import heappush, heappop

class AstarNode:
    # each search node except the root has a parent node
    # and all search nodes wrap a state object

    def __init__(self, state, heuristic, parent=None, transition_cost=0):
        # initialize attributes of AstarNode
        self.state = state
        self.heuristic = heuristic
        self.parent = parent
        self.transition_cost = transition_cost

    def priority(self):
        # calculate note priority based on transition cost and heuristic
        return self.transition_cost + self.heuristic


    # comparison operator,
    # needed for heappush and heappop to work with AstarNodes:
    def __lt__(self, other):
        return self.priority() < other.priority()


# take the current node, and follow its parents back
#  as far as possible. Grab the states from the nodes,
#  and reverse the resulting list of states.
def backchain(node):
    #backtracks from goal state to start state
    result = []
    current = node
    while current:
        result.append(current.state)
        current = current.parent

    result.reverse()
    return result


def astar_search(search_problem, heuristic_fn):
    # Initialize node with start state and heuristic
    start_node = AstarNode(search_problem.start_state, heuristic_fn(search_problem.start_state))
    # Add node to a priority queue
    pqueue = []
    heappush(pqueue, start_node)

    # initializes a solution
    solution = SearchSolution(search_problem, "Astar with heuristic " + heuristic_fn.__name__)

    # make dictionary which keeps track of states and their costs
    visited_cost = {}
    visited_cost[frozenset(start_node.state)] = 0

    # you write the rest:
    while pqueue:
        current_node = heappop(pqueue)
        solution.nodes_visited+=1
        # return solution if found
        if search_problem.is_goal_state(current_node.state):
            print('hi')
            solution.path = backchain(current_node)
            solution.cost = visited_cost[current_node.state]
            return solution

        # get successors and get new cost of child notes
        child_state = search_problem.get_successors(current_node.state)
        movement_cost = 1
        print(child_state)
        new_cost = current_node.transition_cost + movement_cost


        child_node = AstarNode(child_state, heuristic_fn(child_state), current_node, new_cost)
        heappush(pqueue, child_node)
    return solution
