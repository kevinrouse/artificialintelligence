First, run the Maze.py file as this will be used to print and store information about the mazes.

In order to run the mazeworld problem, run the MazeworldProblem.py file and the astar_search.py file as well as the test_mazeworld file. For each maze, the maze is printed and then the solution is given. If you would like to animate the maze, type
{problem_name}.animate_path({result.path}) 

In order to run the sensorless problem, run the Sensorless.py file and the astar_search.py file as well as the test_sensorless.py file. For each maze, the maze is printed and then the solution is given. If you would like to animate the maze, type
{problem_name}.animate_path({result.path}) 