# Kevin Rouse September 26, 2023
from MazeworldProblem import MazeworldProblem
from Maze import Maze

from uninformed_search import bfs_search
from astar_search import astar_search

# null heuristic, useful for testing astar search without heuristic (uniform cost search).
test_maze3 = Maze("maze3.maz")
test_mp = MazeworldProblem(test_maze3, (1, 4, 1, 3, 1, 2))

print(test_maze3)

# this should explore a lot of nodes; it's just uniform-cost search
result = astar_search(test_mp, test_mp.null_heuristic)
print(result)

# this should do a bit better:
result = astar_search(test_mp, test_mp.manhattan_heuristic)
print(result)
# test_mp.animate_path(result.path)

# Your additional tests here

# robot blocking another in 10 x 10 maze
test_maze1 = Maze('10x10.maz')
print(test_maze1)
test_1 = MazeworldProblem(test_maze1, (7, 8, 5, 0))
result = astar_search(test_1, test_1.manhattan_heuristic)
print(result)

# two robots 40x40
test_maze2 = Maze('40x40.maz')
print(test_maze2)
test_2 = MazeworldProblem(test_maze2, (36, 38, 37, 38))
result = astar_search(test_2, test_2.manhattan_heuristic)
print(result)
# three robots, only one linear path
test_maze4 = Maze('5x5.maz')
print(test_maze4)
test_4 = MazeworldProblem(test_maze2, (2, 1, 2, 0, 1, 0))
result = astar_search(test_4, test_4.manhattan_heuristic)
print(result)

# three robots, circular maze, one 'hiding outpost'

test_maze5 = Maze('8x8.maz')
print(test_maze5)
test_5 = MazeworldProblem(test_maze5, (1, 1, 3, 1, 2, 1))
result = astar_search(test_5, test_5.manhattan_heuristic)
print(result)
result = astar_search(test_5, test_5.null_heuristic)
print(result)