# You write this:
from SensorlessProblem import SensorlessProblem
from Maze import Maze
test_maze3 = Maze("maze3.maz")
test_mp = SensorlessProblem(test_maze3)
print(test_maze3)
print(test_mp.get_successors(test_mp.start_state))

if __name__ == "__main__":
    test_maze3 = Maze("maze3.maz")
    print(test_maze3)
    test_problem = SensorlessProblem(test_maze3)

    # Use A* search with the number_of_states_heuristic
    from astar_search import astar_search

    result = astar_search(test_problem, test_problem.number_of_states_heuristic)

    if result:
        print("Solution found!")
        print(result.path)
        test_problem.animate_path(result.path)
    else:
        print("No solution found.")

    test_maze2 = Maze("10x10.maz")
    print(test_maze2)
    test_problem = SensorlessProblem(test_maze2)

    # Use A* search with the number_of_states_heuristic
    from astar_search import astar_search

    result = astar_search(test_problem, test_problem.number_of_states_heuristic)

    if result:
        print("Solution found!")
        print(result.path)
        test_problem.animate_path(result.path)
    else:
        print("No solution found.")