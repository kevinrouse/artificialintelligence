# by Kevin Rouse
class FoxProblem:
    def __init__(self, start_state=(3, 3, 1)):
        '''
        Initialize problem
        :param start_state:
        '''
        self.start_state = start_state
        self.goal_state = (0, 0, 0)
        self.total_chickens = start_state[0]
        self.total_foxes = start_state[1]

    # get successor states for the given state
    def get_successors(self, state):
        # initialize successors
        successors = []
        # actions include: 1 chicken, 1 fox, or both
        actions = [(1, 0), (0, 1), (1, 1), (2,0), (0,2)] if state[2] == 0 else [(-1, 0), (0, -1), (-1, -1),(-2,0),(0,-2)]
        # helper function is is_safe which test if a state is valid
        # tested if states were safe before adding to successor list
        for action in actions:
            new_state = (state[0] + action[0], state[1] + action[1], 1 - state[2])  # Update state

            # Check if new state is safe
            if self.is_safe(new_state):
                successors.append(new_state)
        return successors
    def is_safe(self, state):
        if state[2] == 1:
            chickens_on_start = state[0]
            foxes_on_start = state[1]
            chickens_on_other = self.total_chickens - chickens_on_start
            foxes_on_other = self.total_foxes - foxes_on_start
        else:
            chickens_on_other = state[0]
            foxes_on_other = state[1]
            chickens_on_start = self.total_chickens - chickens_on_other
            foxes_on_start = self.total_foxes - foxes_on_other


        # Check safety on both sides
        return (chickens_on_start == 0 or chickens_on_start >= foxes_on_start) and \
            (chickens_on_other == 0 or chickens_on_other >= foxes_on_other) and chickens_on_start >=0 \
            and foxes_on_other >= 0 and foxes_on_start >= 0 and chickens_on_other >=0

    # create test to see if state is goal
    def goal_test(self, state):
        return state == self.goal_state

    def __str__(self):
        string =  "Foxes and chickens problem: " + str(self.start_state)
        return string


## A bit of test code

if __name__ == "__main__":
    test_cp = FoxProblem((5, 5, 1))
    print(test_cp.get_successors((5, 5, 1)))
    print(test_cp)
