# By Kevin Rouse
from collections import deque
from SearchSolution import SearchSolution

class SearchNode:
    # each search node except the root has a parent node
    # and all search nodes wrap a state object

    def __init__(self, state, parent=None):
        self.state = state
        self.parent = parent
        # you write this part


def bfs_search(search_problem):
    # intialize a set of visited states
    visited = set()
    #create que with start state
    queue = deque([SearchNode(search_problem.start_state)])
    while queue:
        # return leftmost part of queue for every run through which is the node
        node = queue.popleft()
        # get state from this node
        state = node.state
        # test if the state meets the goal and update SearchSolution information
        if search_problem.goal_test(state):
            solution = SearchSolution(search_problem, "BFS")
            solution.path = backchain(node)
            solution.nodes_visited = len(visited)
            return solution
        # if not goal, add to visited
        visited.add(state)
        successors = search_problem
        # get successors of current state
        successors = search_problem.get_successors(state)
        # for all legal successors that are not in visited, add to right side of  queue
        for successor_state in successors:
            if successor_state not in visited:
                child_node = SearchNode(successor_state, parent=node)
                queue.append(child_node)
    solution = SearchSolution(search_problem,'bfs')
    solution.nodes_visited = len(visited)
    return solution
# implement backchain function to get path
def backchain(node):
    # initialize path
    path = []
    while node is not None:
        # add current state to the list
        path.append(node.state)
        # new node is the parent of the child node
        node = node.parent

    return path[::-1]

    # go through queue

def dfs_search(search_problem, depth_limit=100, node=None, solution=None, current_depth = 0):
    # create function to traverse tree to see if it is on the current path
    def is_on_current_path(node, state):
        while node is not None:
            if node.state == state:
                return True
            node = node.parent
        return False
    # function to get path when solution is obtained
    def backchain(node):
        path = []
        while node is not None:
            path.insert(0, node.state)
            node = node.parent
        return path

    # If no node object given, create a new search from starting state
    if node is None:
        node = SearchNode(search_problem.start_state)
    # Initialize solution
    if solution is None:
        solution = SearchSolution(search_problem, "DFS")
    if current_depth > depth_limit:
        return None

    # Test if the current state meets the goal
    if search_problem.goal_test(node.state):
        solution.path = backchain(node)
        return solution

    # Recursively explore successors
    successors = search_problem.get_successors(node.state)
    for successor_state in successors:
        # Avoid revisiting states on the current path
        if not is_on_current_path(node, successor_state):
            child_node = SearchNode(successor_state, parent=node)
            solution.nodes_visited += 1
            # depth is one less since you are now one level down
            result = dfs_search(search_problem, depth_limit - 1, node=child_node, solution=solution, current_depth = current_depth +1)
            # return result if found

            if result is not None:
                return result
def ids_search(search_problem, depth_limit=100):
    #start at 1 and go all the way to depth limit
    for current_depth_limit in range(1, depth_limit + 1):
        result = dfs_search(search_problem, current_depth_limit, solution = SearchSolution(search_problem, "IDS"))
        if result is not None:
            return result