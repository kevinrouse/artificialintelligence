# Foxes and Wolves
Kevin Rouse
## Introduction
In this markdown, we will be solving the Foxes anf Wolves problem.
The problem will be solved with artificial intelligence.
The first step in tackling the problem is to identify possible states.
There are two sides of the river, and in order to save memory, we will represent the states by the starting side as the other side can then be deduced. 

The states will be represented as a tuple (chickens, foxes, boat) where the number of each are the values in the tuple. At the start, there are 3 chickens, 3 foxes, and 1 boat on the starting side, so the starting state is (3,3,1). 
Since there are 3 chickens, 3 foxes, and 1 boat, there are 4 possible numbers for chickens and foxes (0-3) and 2 possible numbers for boat (1 or 2). Therefore, there without considering the legality of the state, there are 4 * 4 * 2 = 32 states. 

The figure attached to the submission file shows the original states and all possible actions from it. 
The resulting states that are in red are illegal because there are more foxes than chickens on one side. By traversing the full tree, one will eventually get to the goal state which is (3,3,0)

[Tree Drawing.pdf](Tree%20Drawing.pdf)
## Implementing the Model

## Code Design
The code is broken up into four separate files. 
These will be discussed in detail but a general overview of the files is as follows. The FoxesProblem.py initializes the problem as well as defines several functions that are used for obtaining information about the current state and the successor states. 
The SearchSolution.py is used to obtain information about the problem and solution and also to print understandable output. The uniformed_search.py file implements the three search algorithm with the  help of the other two aformentioned files, and the foxes.py file is used to test certain instances of the problem.

## Building The Model
In this section, key information about the model will be written in the form of code. The code for this section is located in FoxesProblem.py. 
First, the problem is initialized with the parameter start_state which indicates how many chickens and foxes there are to start. It also contains three other functions which are necessary for implementing the search algorithms.
The first function is get_successors which gets all possible next states from a state. This function does not regard the legality of the successor state so an is_safe function was implemented to determine if a state was safe. Finally, a goal_test function was created to determine if a given state is the goal state.

## Breadth-first search
The first search algorithm that was implemented was Breadth-first search. The code for this is located in uninformed_search.py. The first step was to initialize an empty visited set. A queue was then created and an instance of the SearchNode class with the starting state was added to the queue. While the queue is not empty, the left most element is popped off and checked against
the goal state. If it is not the goal state, the current state is added to visited and the successors are added to the queue. The solution is returned when a state is equal to the goal state or when the queue is empty, indicating there is no solution.

After the solution state is obtained, backchaining is done in order to get the path. Since we were keeping track of the parents for a given node, if we have the goal state, we can keep finding the parents until we get back to the start state. This backchaining function is separated from the bfs_search but is implemented in the bfs_search function.

## Memoizing depth-first search
Although not implemented in the code, the memory aspect of memoizing dfs will be discussed. In a finite space, bfs is O(n) since the frontier is large. For memoizing DFS, the frontier is tiny as you only explore one path at a time. Memoizing DFS is O(d * b) where d is the depth and b is the branching factor. Therefore, it is very unlikely that memoizing DFS saves memory over DFS.

## Path-checking DFS
Path-checking DFS was implemented for the Foxes and Wolves problem. A function called is_on_current_path was created which explores if a node is on the current path. A backchaining function similar to the bfs backchaining function was created. The current state is tested against the goal and returned and backchained if it matches the goal. Otherwise, the successors from the node are determined, and if a successor is not on the current node, the dfs search is recursively called with the successor node. Note that the depth limit is now one less as our current depth has increased by 1. The process is recursively repeated until either a solution is found or the depth limit is reached.

Path-checking DFS saves significant memory with respect to BFS because in path-checking DFS, we do not keep track of the visited states but instead the current path. However, path-checing DFS can take more runtime depending on where the goal state(s) are. In the attached figure

[BFS vs DFS.pdf](BFS%20vs%20DFS.pdf)

For example, looking at the attached figure, bfs will get to the goal state quickly as it is only 3 levels away. However, assuming that path-checking DFS checks paths from left to right, it will explore all of the other possible paths before getting to the path that leads to the goal. 

## Iterative deepening search
On a graph, DFS takes more memory than it does on a tree because the path can be cylical and without keeping track of visited states, can be redundant. A way to balance memory while still finding the shortest path is to implement iterative deep search.
The depth is started at 1 and keeps going up until the depth limit is reached. At each depth limit, the dfs algorithm is implemented fully. My code does this by implementing a for loop that goes from 1 to the depth limit and implements the dfs code and returns a solution if found.
On a graph, I would still implement path checking DFS due to the memory that is saved. The time aspect will likely be similar as we will find the goal in the least amount of steps due to the IDS approach.

## Lossy Chickens and Foxes
If we say that some chickens can be eaten, a new parameter to the problem, E is added, where E is the number of chickens that can be eaten. The state should also have a new parameter,Ce, or chickens eaten. Therefore, the new state is (chickens on start, foxes on start, boat, chickens eaten). The functions would also have to be changed to allow more foxes than chickens if there is room for chickens to be eaten (as long as E > Ce, a chicken can be eaten). If the starting number of chickens is Cs, starting foxes is Fs, and E is number of chickens that can be eaten, the number of possible states is (Cs + 1) * (Fs +1) * 2 * (E+1).  