# Testing
from CSP import *
import time
# Map coloring without AC3
from MapColoringCSP import *
from CircuitBoard import *
map_csp = MapColoringCSP()
start_time = time.time()
solution = map_csp.backtracking_search()
end_time = time.time()
print(f"Domain without AC3 (assuming South Australia is red): {map_csp.domains}")
print("Solution of Map coloring without ac3:")
if solution is not None:
    map_csp.print_solution(solution)
else:
    print("No solution found.")
print(f"Runtime for no AC3 map problem:{end_time-start_time}")

###############################################
from MapColoringCSP import *
start_time = time.time()
map_csp = MapColoringCSP()
map_csp.ac3() # take out or add this line to do ac3
print(f"Domain with AC3 (assuming South Australia is red): {map_csp.domains}")
solution = map_csp.backtracking_search()
end_time = time.time()
print("Solution of Map coloring with ac3:")
if solution is not None:
    map_csp.print_solution(solution)
else:
    print("No solution found.")
print(f"Runtime for AC3 map problem:{end_time-start_time}")
####################################################
# Define the board dimensions and components
board_width = 10
board_height = 3
components = {
    'a': (3, 2),
    'b': (5, 2),
    'c': (2, 3),
    'e': (7, 1)
}
# circuit without ac3
start_time = time.time()
circuit_csp = CircuitBoardCSP(board_width, board_height, components)
solution = circuit_csp.backtracking_search()
end_time = time.time()
print(f"Domain without AC3 (assuming e block is at (0,0): {circuit_csp.domains}")
print("Solution of Map coloring without ac3:")
if solution is not None:
    display_solution(solution, board_width, board_height,components)
else:
    print("No solution found.")
print(f"Runtime for no AC3 circuit problem:{end_time-start_time}")
##########################################
# circuit with ac3
start_time - time.time()
circuit_csp = CircuitBoardCSP(board_width, board_height, components)
circuit_csp.ac3()
solution = circuit_csp.backtracking_search()
end_time - time.time()
print(f"Domain with AC3 (assuming e block is at (0,0): {circuit_csp.domains}")
print("Solution of Map coloring with ac3:")
if solution is not None:
    display_solution(solution, board_width, board_height,components)
else:
    print("No solution found.")
print(f"Runtime for AC3 circuit problem:{end_time-start_time}")
######################
start_time = time.time()
map_csp = MapColoringCSP()
solution = map_csp.backtracking_search(use_mrv=True)
end_time = time.time()
print(f"Domain without AC3 (assuming South Australia is red): {map_csp.domains}")
print("Solution of Map coloring without ac3:")
if solution is not None:
    map_csp.print_solution(solution)
else:
    print("No solution found.")
print(f"Runtime for map problem with mrv:{end_time-start_time}")

####
######################
start_time = time.time()
map_csp = MapColoringCSP()
solution = map_csp.backtracking_search(use_lcv=True)
end_time = time.time()
print(f"Domain without AC3 (assuming South Australia is red): {map_csp.domains}")
print("Solution of Map coloring without ac3:")
if solution is not None:
    map_csp.print_solution(solution)
else:
    print("No solution found.")
print(f"Runtime for map problem with lcv:{end_time-start_time}")

####
# circuit with lcv
start_time = time.time()
circuit_csp = CircuitBoardCSP(board_width, board_height, components)
solution = circuit_csp.backtracking_search(use_lcv=True)
end_time = time.time()
print(f"Domain without AC3 (assuming e block is at (0,0): {circuit_csp.domains}")
print("Solution of Map coloring without ac3:")
if solution is not None:
    display_solution(solution, board_width, board_height,components)
else:
    print("No solution found.")
print(f"Runtime for map circuit with lcv:{end_time-start_time}")
####
# circuit with mcv
start_time = time.time()
circuit_csp = CircuitBoardCSP(board_width, board_height, components)
solution = circuit_csp.backtracking_search(use_mrv=True)
end_time = time.time()
print(f"Domain without AC3 (assuming e block is at (0,0): {circuit_csp.domains}")
print("Solution of Map coloring without ac3:")
if solution is not None:
    display_solution(solution, board_width, board_height,components)
else:
    print("No solution found.")
print(f"Runtime for map circuit with mcv:{end_time-start_time}")

# circuit with both mcv and lcv
start_time = time.time()
circuit_csp = CircuitBoardCSP(board_width, board_height, components)
solution = circuit_csp.backtracking_search(use_mrv=True,use_lcv=True)
end_time = time.time()
print(f"Domain without AC3 (assuming e block is at (0,0): {circuit_csp.domains}")
print("Solution of Map coloring without ac3:")
if solution is not None:
    display_solution(solution, board_width, board_height,components)
else:
    print("No solution found.")
print(f"Runtime for map circuit with both lcv and mcv:{end_time-start_time}")