from CSP import CSP, Constraint


class CircuitBoardCSP(CSP):
    def __init__(self, board_width, board_height, components, ac3=True):
        # initialize empty list for variables
        variables = []
        # initialize empty dictionary for domains
        domains = {}
        # assuming lower left corner of piece is x,y coordinate for each piece
        # use board width and height as well as component width and height to get possible positions (domain)
        for component_name, (component_width, component_height) in components.items():
            component_domain = [(x, y) for x in range(board_width - component_width + 1)
                                for y in range(board_height - component_height + 1)]
            variables.append(component_name)
            domains[component_name] = component_domain
        # initialize self's variables, domains, constraints(empty)
        super().__init__(variables, domains)
        # add constraints that doesn't allow pieces to overlap
        self.add_non_overlap_constraints(components)

    def add_non_overlap_constraints(self, components):
        # loop through each component
        for component1_name, (component1_width, component1_height) in components.items():
            # loop through all other components
            for component2_name, (component2_width, component2_height) in components.items():
                if component1_name != component2_name:
                    # add constraint which says they can't overlap
                    self.add_constraint(
                        NonOverlapConstraint(component1_name, component2_name,
                                             component1_width, component1_height,
                                             component2_width, component2_height)
                    )


class NonOverlapConstraint(Constraint):
    # initialize two components as well as their widths and heights
    def __init__(self, component1, component2, w1, h1, w2, h2):
        super().__init__([component1, component2])
        self.component1 = component1
        self.component2 = component2
        self.w1 = w1
        self.h1 = h1
        self.w2 = w2
        self.h2 = h2

    def satisfied(self, assignment):
        # constraint will be satisfied is one of the pieces is not there yet
        if self.component1 not in assignment or self.component2 not in assignment:
            return True
        # get x and y positions of both pieces in the assignment
        x1, y1 = assignment[self.component1]
        x2, y2 = assignment[self.component2]
        # use width and heights of the pieces to check if they overlap, return false if they do
        return (x1 + self.w1 <= x2) or (x2 + self.w2 <= x1) or (y1 + self.h1 <= y2) or (y2 + self.h2 <= y1)



def display_solution(solution, board_width, board_height,components):
    # make empty board
    board = [['.' for _ in range(board_width)] for _ in range(board_height)]
    # for each component in the solution, iterate through all values
    for component, (x, y) in solution.items():
        for i in range(x, x + components[component][0]):
            for j in range(y, y + components[component][1]):
                # replace . with component
                board[j][i] = component
    for row in board:
        print(''.join(row))






