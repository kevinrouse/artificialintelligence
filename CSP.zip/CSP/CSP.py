# Kevin Rouse
from collections import deque
class CSP:
    def __init__(self, variables, domains):
        # variables should be a list of all the variables
        self.variables = variables  # variables to be constrained
        # domains should be a dictionary where each variable has a list of domains
        self.domains = domains  # domain of each variable
        # want to start with no constraints because this depends on the problem
        self.constraints = {variable: [] for variable in self.variables}
        # will be updated in subclasses
        self.arcs = {}
    def add_constraint(self, constraint):
        # add the constraint to the variables
        for variable in constraint.values:
            self.constraints[variable].append(constraint)
    # determines if the assignment is consistent with the constraints
    def consistent(self, variable, assignment):
        # tests if assignment satisfies constraint for a given variable
        for constraint in self.constraints[variable]:
            if not constraint.satisfied(assignment):
                return False
        return True

    def backtracking_search(self, assignment={}, use_mrv = False, use_lcv = False):
        # assignment is complete if every variable is assigned
        if len(assignment) == len(self.variables):
            return assignment
        # get unassigned variables
        unassigned = [v for v in self.variables if v not in assignment]

        # get the next unassigned variable
        next = unassigned[0]
        for value in self.domains[next]:
            # assign a value in the domain to the next value
            local_assignment = assignment.copy()
            local_assignment[next] = value
            # recurse if consistent
            if self.consistent(next, local_assignment):
                result = self.backtracking_search(local_assignment)
                # return result if found
                if result is not None:
                    return result
        # return none if no result found
        return None

    def backtracking_search(self, assignment={}, use_mrv=True, use_lcv=True):
        # assignment is complete if every variable is assigned
        if len(assignment) == len(self.variables):
            return assignment

        # get unassigned variables
        unassigned = [v for v in self.variables if v not in assignment]

        # Apply MRV heuristic if enabled
        if use_mrv:
            unassigned = sorted(unassigned, key=lambda var: len(self.domains[var]))

        next = unassigned[0]
        local_assignment = assignment.copy()

        # Apply LCV heuristic if enabled
        if use_lcv:
            domain = self.domains[next]
            # sort domain by number of possible values of neighbors
            domain = sorted(domain, key=lambda v: sum(
                1 for neighbor in self.get_neighbors(next) if v in self.domains[neighbor]
            ))
            # assign a consistent value and recurse
            for val in domain:
                local_assignment[next] = val
                if self.consistent(next, local_assignment):
                    result = self.backtracking_search(local_assignment, use_mrv, use_lcv)
                    if result is not None:
                        return result

        # If LCV is not enabled or no result found with LCV
        for value in self.domains[next]:
            local_assignment[next] = value
            # assign consistent value and recurse
            if self.consistent(next, local_assignment):
                result = self.backtracking_search(local_assignment, use_mrv, use_lcv)
                if result is not None:
                    return result
        return None

    # implemented pseudeocode from https://stackoverflow.com/questions/28257422/ac-1-ac-2-and-ac-3-algorithms-arc-consistency
    def ac3(self):
        # initialize queue with all of the arcs
        queue = deque(self.arcs)
        while queue:
            # start popping arcs from the queue and remove inconsistent values
            X, Y = queue.pop()
            if self.RemoveInconsistentValues(X, Y):
                for Z in self.get_neighbors(X):
                    queue.append((Z, X))


    def RemoveInconsistentValues(self, X, Y):
        valueRemoved = False
        # had trouble because if only 1 value in domain returned int so made all values ints
        for x in self.domains[X]:
            if isinstance(x, list):
                x = int(x[0])
            # if consistent, go to next x
            # Check if there exists any consistent value of Y for the current X
            # if none are found consistent, remove inconsistent values from X
            if not any(
                    self.is_legal(X, {X: x, Y: y})
                    for y in self.domains[Y]
            ):
                self.domains[X].remove(x)
                valueRemoved = True

        return valueRemoved

    def is_legal(self, X, assignment):
        # return true if all constraints are satisfied
        for constraint in self.constraints[X]:
            if not constraint.satisfied(assignment):
                return False
        return True

    def get_neighbors(self, variable):
        neighbors = set()
        # get neighbors in each arc
        for arc in self.arcs:
            if variable in arc:
                neighbors.add(arc[0] if arc[1] == variable else arc[1])

        return neighbors

    def apply_mrv_heuristic(self, unassigned):
        # returns mrv heuristic
        return sorted(unassigned, key=lambda var: len(self.domains[var]))

    def apply_lcv_heuristic(self, variable):
        # apply lcv
        def count_constraints(value):
            local_assignment = assignment.copy()
            local_assignment[variable] = value
            count = 0
            # find least constraining variable
            for constraint in self.constraints[variable]:
                if not constraint.satisfied(local_assignment):
                    count += 1
            return count
        return sorted(self.domains[variable], key=count_constraints, reverse=True)


# implement a constraint class that will be changed depending on the problem.
class Constraint:
    def __init__(self, values):
        # initialize the values of the constraint
        self.values = values
    # satisfied determines if the assignment satisfies the constraint
    def satisfied(self, assignment):
        raise NotImplementedError("Subclasses must implement satisfied method")

