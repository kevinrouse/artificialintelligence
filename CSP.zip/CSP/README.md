In my test.py, I have provided a few examples but if you would like to run your own examples, follow this template:
```from MapColoringCSP import *
start_time = time.time()
csp = {Insert CSP of choice}()
csp.ac3() # if you want to run ac3
solution = csp.backtracking_search(mrv = {True or False}, lcv = {True or False ) # toggle heuristics on and off
end_time = time.time()
if solution is not None:
    map_csp.print_solution(solution)
else:
    print("No solution found.")
print(f"Runtime problem:{end_time-start_time}")```