# CSP Assignment

## Introduction
The goal of this assignment is to create a generic constraint satisfaction problem and then to apply it to two problems. The first problem it will be applied to is the Australia map coloring problem. The second problem it will be applied to is the circuit board problem which invlolves fitting pieces on a board without them overlapping.

## Implementation of Basic CSP
The three crucial pieces of information for a constraint satisfaction are the variables, domains (possible values that can be assigned to each domain), and constraints (rules for certain assignments of variables). The first step of the program was to initialize these variables. The CSP class takes in the parameters variables and domains, where variables is a list of all possible variables and domains is a dictionary where the variables are the keys and the domains are the values. Constraints are initialized to be empty because these change based on the problem and must be updated in subclasses. Since constraints are defined in the subclasses, a method was created in CSP that adds these constraints to the respective variable. A class for constraints was also created to make it easier to handle constraints and to update the constraints in subclasses.

After all the constraints, domains, and variables are all in the class, the backtracking search can be called. The basic functionality of the backtracking function is to solve the CSP. It does that by taking unassigned variables one by one and giving them an assignment. It enforces consistency and recursively calls itself until a solution is found.

## Map Coloring
In order to solve the map problem, it is first initialized as a subclass of CSP with the variables being integers ranging from 0 to 6, representing each area of the map. Since the goal is to solve the problem only using three colors, the domain for each variable was [1,2,3] , where each integer was a different color. The integers for the variables and domains will be mapped to the actual places/colors at the end. In order to get the constraints, an adjacency list was created which represented which variables were next to each other and could not be the same color. For each pair in the adjacency list, a MapColoringConstraint instance was created. With these constraints, variables, and domains, the backtracking solver was called and returned a valid solution. Since the program used integers, these values were then mapped to the region/colors name to print the result. The solution retrieved by the algorithm was: 

South Australia is Red

Western Australia is Green

Northern Territory is Blue

Queensland is Green

New South Wales is Blue

Victoria is Green

Tasmania is Red

## Circuit Board
The circuit board problem involves fitting rectangular pieces of certain widths and heights onto a rectangular board. This problem is initialized in the CircuitBoard.py file and is a subclass of CSP. For the variables, each piece was given a distance letter name that represented it. For each piece, the possible domains involve x,y coordinates that represent the bottom left part of the piece. Based on the dimensions of the piece and the dimensions of the board, some values were ruled out. The main difference between this problem and map coloring are the constraints. In MapColoring, the constraints were represented by an adjacency list. In this problem, the constraints are that the pieces cannot be overlapping. Our circuit board constraint checks if the pieces are overlapping and for overlapping assignments, they are considered invalid. With these variables, constraints, and domains, the same backtracing function is called which returns the solution. The solution was then printed in ASCII art. The solution obtained was:

ccbbbbbaaa

ccbbbbbaaa

cceeeeeee.

## MAC-3
The inference technique MAC-3 was then implemented to try and reduce the domain of the variables. The way this works is it takes all possible arcs, adds them to a queue, and enforces arc consistency.
I set the color of South Australia to red and employed the ac-3 algorithm. The resulting domain was {0: [2, 3], 1: [2, 3], 2: [1], 3: [2, 3], 4: [2, 3], 5: [2, 3], 6: [1, 2, 3]}. Without ac-3, the possible domains for all of the countries is [1,2,3]. Therefore, ac-3 helps reduce the domain space. However, the run time between implementing ac-3 and not was essentially the same. This can be attributed to the very short run time of the program (less than one millisecond).

## Adding Heuristics
The first heuristics added to the system was the least-constraining value heuristic. This heuristic involves picking the value that is least constraining on other variables. This is the value that is most likely to lead to the solution so it was picked first. This was implemented in the backtracking search and can be toggled on and off when testing. The second heuristic used was minimum remaining values (MRV). This heuristic selects the variables with the least amount of remaining values. This is a good heuristic because it allows you to fail fast if a solution does not work and to explore other possibilities. This was also implemented in the backtracking search and can be toggled on and off. However, the run time between implementing these heuristics and not was essentially the same. This can be attributed to the very short run time of the program (less than one millisecond).
