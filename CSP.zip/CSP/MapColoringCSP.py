from CSP import CSP
from CSP import  Constraint

# Map Coloring CSP inherits from CSP
class MapColoringCSP(CSP):
    def __init__(self):
        # Define the variables and their domains
        variables = list(range(0, 7))  # Variables representing regions (0-6), will be mapped later
        domains = {var: [1, 2, 3] for var in variables}
        # Using integers to represent colors (1=Red, 2=Green, 3=Blue)
        super().__init__(variables, domains) # initialize self's v, d, c
        self.domains[2]=[1]

        # Add adjacency constraints
        adjacency_list = [(0, 1), (0, 2), (1, 2), (1, 3), (2, 3), (2, 4), (2, 5),
                          (3, 4), (4, 5)]
        self.add_adjacency_constraints(adjacency_list)
        arcs = []
        for variable in self.constraints.values():
            for constraint in variable:
                arcs.extend(constraint.generate_arcs())
        self.arcs = set(arcs)
    def add_adjacency_constraints(self, adjacency_list):
        # loop through adjacency list and add constraint for each pair
        for territory1, territory2 in adjacency_list:
            self.add_constraint(
                MapColoringConstraint(territory1, territory2)
            )
    # map the integers to real places and colors
    def print_solution(self, solution):
        territory_names = [
            'Western Australia',
            'Northern Territory',
            'South Australia',
            'Queensland',
            'New South Wales',
            'Victoria',
            'Tasmania'
        ]

        territory_colors = {
            1: 'Red',
            2: 'Green',
            3: 'Blue'
        }

        for territory, color in solution.items():
            print(f"{territory_names[territory]} is {territory_colors[color]}")

class MapColoringConstraint(Constraint):
    # initialize each pair as a constraint
    def __init__(self, place1, place2):
        super().__init__([place1, place2])
        self.place1 = place1
        self.place2 = place2
    # constraint is satisfied if the two assignments are different
    def satisfied(self, assignment):
        if self.place1 not in assignment or self.place2 not in assignment:
            return True
        return assignment[self.place1] != assignment[self.place2]
    def generate_arcs(self):
        return [(self.place1, self.place2), (self.place2, self.place1)]
