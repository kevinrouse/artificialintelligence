 #pip3 install python-chess


import chess
from RandomAI import RandomAI
from HumanPlayer import HumanPlayer
from MinimaxAI import MinimaxAI
from MinimaxAIHash import MinimaxAIHash
from AlphaBetaAI import AlphaBetaAI
from AlphaBetaAIHash import AlphaBetaAIHash
from ChessGame import ChessGame
from IDS_minimax import IterativeDeepeningAI
####################################################
# Random AI
'''import sys


player1 = HumanPlayer()
player2 = RandomAI()

game = ChessGame(player1, player2)

while not game.is_game_over():
    print(game)
    game.make_move()

#print(hash(str(game.board)))'''

####################################################

# Minimax no Hashing

'''# Step 1: Create an instance of MinimaxAI
ai_player = MinimaxAI(depth=4)  # You can adjust the depth as needed

# Step 2: Initialize a ChessGame with the AI player
player1 = HumanPlayer()
player2 = ai_player

game = ChessGame(player1, player2)

# Step 3: Modify the game loop
while not game.is_game_over():
    print(game)

    # Human player's turn
    if isinstance(game.players[0], HumanPlayer):
        game.make_move()
    else:
        ai_move = game.players[0].choose_move(game.board)

print("Game Over!")'''
############################################

# Iterative deepening w/minimax
'''# Step 1: Create an instance of IDS
ai_player = IterativeDeepeningAI(max_depth=4)  # You can adjust the depth as needed

# Step 2: Initialize a ChessGame with the AI player
player1 = HumanPlayer()
player2 = ai_player

game = ChessGame(player1, player2)

# Step 3: Modify the game loop
while not game.is_game_over():
    print(game)

    # Human player's turn
    if isinstance(game.players[0], HumanPlayer):
        game.make_move()
    else:
        ai_move = game.players[0].choose_move(game.board)
        game.board.push(ai_move)

print("Game Over!")'''

###############################################
# Alpha beta no hashing

'''# Step 1: Create an instance of AlphaBeta
ai_player = AlphaBetaAI(depth=6)  # You can adjust the depth as needed

# Step 2: Initialize a ChessGame with the AI player
player1 = HumanPlayer()
player2 = ai_player

game = ChessGame(player1, player2)

# Step 3: Modify the game loop
while not game.is_game_over():
    print(game)

    # Human player's turn
    if isinstance(game.players[0], HumanPlayer):
        game.make_move()
    else:
        ai_move = game.players[0].choose_move(game.board)
        game.board.push(ai_move)
print("Game Over!")'''
###################################################
# MiniMax Hashing
'''# Step 1: Create an instance of MinimaxAIHash
ai_player = MinimaxAIHash(depth=5)  # You can adjust the depth as needed

# Step 2: Initialize a ChessGame with the AI player
player1 = HumanPlayer()
player2 = ai_player

game = ChessGame(player1, player2)

# Step 3: Modify the game loop
while not game.is_game_over():
    print(game)

    # Human player's turn
    if isinstance(game.players[0], HumanPlayer):
        game.make_move()
    else:
        ai_move = game.players[0].choose_move(game.board)
        game.board.push(ai_move)

print("Game Over!")'''
###################################################
# AlphaBetaHashing

# Step 1: Create an instance of AlphaBetaHashing
'''ai_player = AlphaBetaAIHash(depth=5)  # You can adjust the depth as needed

# Step 2: Initialize a ChessGame with the AI player
player1 = HumanPlayer()
player2 = ai_player

game = ChessGame(player1, player2)

# Step 3: Modify the game loop
while not game.is_game_over():
    print(game)

    # Human player's turn
    if isinstance(game.players[0], HumanPlayer):
        game.make_move()
    else:
        ai_move = game.players[0].choose_move(game.board)
        game.board.push(ai_move)

print("Game Over!")'''