import chess

class MinimaxAIHash():
    def __init__(self, depth):
        #initialize depth
        self.max_depth = depth
        self.transposition_table = {}

    # minimax search algorithm adapted from figure 5.3 of "Stuart Russell, Peter Norvig - Artificial Intelligence_ A Modern Approach (4th Edition) (Pearson Series in Artifical Intelligence)-Language_ English (2020)"

    def choose_move(self, board):
        # first element of max_value called at the max depth extracts the best move
        self.minimax_calls = 0
        best_move, _ = self.max_value(board, self.max_depth)
        print(f"Minimax calls: {self.minimax_calls}")
        print(f"Maximum depth reached: {self.max_depth}")
        return best_move


    def max_value(self, board, depth):
        '''
        :param board:
        :param depth:
        :return:
        # finds max value of moves at certain depth assuming min is picking the min value
        '''
        # make current key current board
        key = hash(str(board))
        # if already explored, return result from that exploration
        if key in self.transposition_table and self.transposition_table[key]['depth'] >= depth:
            entry = self.transposition_table[key]
            if entry['exact']:
                return entry['move'], entry['value']
        self.minimax_calls += 1
        # if game over or max depth reached, get evaluation of position if end state or max depth reached
        if self.cutoff_test(board, depth):
            return None, self.evaluate(board)
        # set really small value because subsequent values will be larger
        best_value = float('-inf')
        best_move = None
        # go through legal moves
        for move in board.legal_moves:
            board.push(move)
            # get max value of mins possible moves that are one step ahead
            _, value = self.min_value(board, depth - 1)
            board.pop()

            if value > best_value:
                best_value = value
                best_move = move
        self.store_transposition(board, depth, best_move, best_value)
        return best_move, best_value

    def min_value(self, board, depth):
        '''
        :param board:
        :param depth:
        :return:
        # finds min value of moves at certain depth assuming max is picking the max value
        '''
        # make current key current board
        key = hash(str(board))
        # if already explored, return result from that exploration
        if key in self.transposition_table and self.transposition_table[key]['depth'] >= depth:
            entry = self.transposition_table[key]
            if entry['exact']:
                return entry['move'], entry['value']
        self.minimax_calls += 1
        # if game over or max depth reached, get evaluation of position if end state or max depth reached
        if self.cutoff_test(board, depth):
            return None, self.evaluate(board)
        # set really large value because subsequent values will be smaller
        best_value = float('inf')
        best_move = None
        # go through legal moves
        for move in board.legal_moves:
            board.push(move)
            # get min value of maxs possible moves that are one step ahead
            _, value = self.max_value(board, depth - 1)
            board.pop()
            if value < best_value:
                best_value = value
                best_move = move
        self.store_transposition(board, depth, best_move, best_value)
        return best_move, best_value

    def cutoff_test(self, board, depth):
        # cutoff is when max depth is reached or when an end state for the board is reached
        return depth == 0 or board.is_game_over()

    def evaluate(self, board):
        # chose material values as heurisitc as this indicates how good a position is
        material_values = {
            chess.PAWN: 1,
            chess.KNIGHT: 3,
            chess.BISHOP: 3,
            chess.ROOK: 5,
            chess.QUEEN: 9,
            chess.KING: 500  # set kings value to 500 since it is very valuable
        }

        score = 0
        # if square is on your side add, otherwise subtract
        for square, piece in board.piece_map().items():
            if piece.color == 'black':
                score += material_values[piece.piece_type]
            else:
                score -= material_values[piece.piece_type]

        return score
    def hash_board(self, board):
        return hash(str(board))

    # takes a state and stores it in the transposition table
    def store_transposition(self, board, depth, move, value):
        key = self.hash_board(board)
        self.transposition_table[key] = {
            'depth': depth,
            'move': move,
            'value': value,
            'exact': True  # Indicate that this is an exact match
        }
