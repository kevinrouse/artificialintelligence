import chess
from math import inf


class AlphaBetaAI():
    def __init__(self, depth):
        #initialize depth
        self.max_depth = depth

    def choose_move(self, board):
        # first element of max_value called at the max depth extracts the best move
        self.minimax_calls = 0
        # call max_value at max depth to get best move
        best_move, _ = self.max_value(board, self.max_depth, float('-inf'), float('inf'))
        print(f"Minimax calls: {self.minimax_calls}")
        print(f"Maximum depth reached: {self.max_depth}")
        return best_move

    def max_value(self, board, depth, alpha, beta):
        # increment the minimax calls counter
        self.minimax_calls += 1
        # test to see if it is the cutoff
        if self.cutoff_test(board, depth):
            return None, self.evaluate(board)
        # initialize very small value for max
        best_value = float('-inf')
        best_move = None
        # reorder moves based on if they are captures
        legal_moves = sorted(board.legal_moves, key=lambda move: board.is_capture(move), reverse = True)
        # go through legal moves
        for move in legal_moves:
            board.push(move)
            # get mins value at one depth lower
            _, value = self.min_value(board, depth - 1, alpha, beta)
            board.pop()
            # if the value is better, take it and change the move
            if value > best_value:
                best_value = value
                best_move = move
            # update alpha if needed
            alpha = max(alpha, best_value)
            # break out of current loop if beta <= alpha since further exploration is unnecessary
            if beta <= alpha:
                break
        return best_move, best_value

    def min_value(self, board, depth, alpha, beta):
        # increment number of calls
        self.minimax_calls += 1
        # evaluate position if cutoff reached, no next move so return None
        if self.cutoff_test(board, depth):
            return None, self.evaluate(board)
        # initialize large value for min
        best_value = float('inf')
        best_move = None
        # reorder moves based on positional values
        legal_moves = sorted(board.legal_moves, key=lambda move: board.is_capture(move), reverse=True)
        # iterate through moves and get values
        for move in legal_moves:
            board.push(move)
            _, value = self.max_value(board, depth - 1, alpha, beta)
            board.pop()
            # update best value if better
            if value < best_value:
                best_value = value
                best_move = move
            # update beta
            beta = min(beta, best_value)
            # break out of current loop if beta <= alpha since further exploration is unnecessary
            if beta <= alpha:
                break
        return best_move, best_value

    def cutoff_test(self, board, depth):
        # game is done when depth limit reached or end state reached
        return depth == 0 or board.is_game_over()

    def evaluate(self, board):
        # used material values as heuristic
        material_values = {
            chess.PAWN: 1,
            chess.KNIGHT: 3,
            chess.BISHOP: 3,
            chess.ROOK: 5,
            chess.QUEEN: 9,
            chess.KING: 500
        }

        score = 0

        for square, piece in board.piece_map().items():
            if piece.color == 'black':
                score += material_values[piece.piece_type]
            else:
                score -= material_values[piece.piece_type]

        return score

    def evaluate_move(self, board, move):
        # Determines if a move is a capturing move
        captured_piece = board.piece_at(move.to_square)
        if captured_piece is not None:
            return self.evaluate(board) + self.evaluate_piece(captured_piece)
        return self.evaluate(board)
