import chess
from MinimaxAI import MinimaxAI
class IterativeDeepeningAI(MinimaxAI):
    def __init__(self, max_depth):
        super().__init__(max_depth)

    def choose_move(self, board):
        self.minimax_calls = 0
        best_move = None

        for depth in range(1, self.max_depth + 1):
            new_best_move, _ = self.max_value(board, depth)
            if new_best_move is not None:
                best_move = new_best_move
                print(f"Depth {depth}: Best Move: {best_move}")

        print(f"Minimax calls: {self.minimax_calls}")
        print(f"Maximum depth reached: {self.max_depth}")
        return best_move